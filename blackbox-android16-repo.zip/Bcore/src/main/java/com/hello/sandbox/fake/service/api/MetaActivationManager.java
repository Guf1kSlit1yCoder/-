package com.hello.sandbox.fake.service.api;

import com.hello.sandbox.SandBoxCore;

public class MetaActivationManager {

    private static boolean licenseActivated = true;

    public static void activateSdk(String licenseKey) {
        LicenseVerifier.verify(licenseKey, new LicenseVerifier.Callback() {
			@Override
			public void onResult(boolean isValid, String message) {
				licenseActivated = isValid;
			}
		});
    }

    public static boolean isLicenseActivated() {
        return licenseActivated;
    }
}
